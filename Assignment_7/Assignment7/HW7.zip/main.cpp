#include <iostream>
#include "WordCounts.h"
#include "SpellChecker.h"

using namespace std;

int main()
{

}
