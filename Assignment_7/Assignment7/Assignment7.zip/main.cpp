//Justin Hayward
//CSCI 1300-106, Tom
//
//Assignment 7

#include <iostream>
#include <sstream>
#include "WordCounts.h"
#include "SpellChecker.h"
//#include "SpellChecker.cpp"
//#include "WordCounts.cpp"

using namespace std;

int main()
{
    //SpellChecker sc();

    //SpellChecker sc2("english");
    //cout<<"language is set as: "<<sc2.language<<endl;

    //SpellChecker sc3("english", "VALID_WORDS_3000.txt", "MISSPELLED.txt");
    //cout<<"language is set as: "<<sc3.language<<endl;
    //cout<<"valid words read? "<<sc3.readValidWords()<<endl;
    //cout<<"corrected words read? "<<sc3.readCorrectedWords<<endl;

    //cout<<sc2.readValidWords("VALID_WORDS_3000.txt")<<'\n';
    //cout<<sc2.readValidWords("VALID_WORDS_3000.txt")<<'\n';
    //sc2.readCorrectedWords("MISSPELLED.txt");
    //sc2.readCorrectedWords("Text2English.txt");

    //cout<<sc2.repair("todayy")<<endl;
    //cout<<sc.readCorrectedWords("MISSPELLED.txt")<<'\n';

    //SpellChecker sc2;
    //bool x=sc2.setStartMarker('~');
    //bool y=sc2.setEndMarker('~');
    //cout<<x<<"  "<<y<<endl;

    //sc2.readCorrectedWords("MISSPELLED.txt");
    //sc2.readCorrectedWords("MISSPELLED.txt");

    //cout<<sc2.repair("hello world")<<endl;
    //cout<<sc2.repair("todayy")<<endl;
    //cout<<sc2.repair("yshdf")<<endl;
    //cout<<sc2.repair("**today**")<<endl;

    /*
    WordCounts wc;
    wc.tallyWords("the blue brown fox fox");
    wc.tallyWords("the the green cat");

    int y=wc.getTally("the");
    cout<<y<<endl;

    string wordArr[1000];
    int countArr[1000];

    wc.mostTimes(wordArr, countArr, 2);
    */

    //SpellChecker sc4("", "VALID_WORDS_3000.txt", "MISSPELLED.txt");
    //cout<<sc4.repair("comedy world");
}
